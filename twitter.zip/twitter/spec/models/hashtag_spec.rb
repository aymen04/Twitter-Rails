require 'rails_helper'

RSpec.describe Hashtag, type: :model do
  describe 'when tweet body is less than 1 character' do
    it 'does not accept contentless tweets' do
      expect { FactoryBot.create(:hashtag, body: '') }.to raise_exception
    end
  end
end

describe 'when hashtag body is more than 280 characters' do
  it 'does not accept too long hashtags' do
    expect { FactoryBot.create(:hashtag, body: Faker::Hipster.paragraph_by_chars(characters: 300, supplemental: false)) }.to raise_exception
  end
end