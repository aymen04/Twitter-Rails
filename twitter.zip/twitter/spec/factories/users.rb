FactoryBot.define do
    factory :user do
      full_name { Faker::Kpop.girl_groups }
      nickname { Faker::Kpop.boys_band }
      password { '123456&678' }
    end
  end