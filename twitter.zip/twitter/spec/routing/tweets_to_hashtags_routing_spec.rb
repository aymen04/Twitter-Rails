require "rails_helper"

RSpec.describe TweetsToHashtagsController, type: :routing do
  describe "routing" do
    it "routes to #index" do
      expect(get: "/tweets_to_hashtags").to route_to("tweets_to_hashtags#index")
    end

    it "routes to #new" do
      expect(get: "/tweets_to_hashtags/new").to route_to("tweets_to_hashtags#new")
    end

    it "routes to #show" do
      expect(get: "/tweets_to_hashtags/1").to route_to("tweets_to_hashtags#show", id: "1")
    end

    it "routes to #edit" do
      expect(get: "/tweets_to_hashtags/1/edit").to route_to("tweets_to_hashtags#edit", id: "1")
    end


    it "routes to #create" do
      expect(post: "/tweets_to_hashtags").to route_to("tweets_to_hashtags#create")
    end

    it "routes to #update via PUT" do
      expect(put: "/tweets_to_hashtags/1").to route_to("tweets_to_hashtags#update", id: "1")
    end

    it "routes to #update via PATCH" do
      expect(patch: "/tweets_to_hashtags/1").to route_to("tweets_to_hashtags#update", id: "1")
    end

    it "routes to #destroy" do
      expect(delete: "/tweets_to_hashtags/1").to route_to("tweets_to_hashtags#destroy", id: "1")
    end
  end
end
