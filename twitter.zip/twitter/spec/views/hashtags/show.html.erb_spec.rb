require 'rails_helper'

RSpec.describe "hashtags/show", type: :view do
  before(:each) do
    @hashtag = assign(:hashtag, Hashtag.create!(
      hashtag: "Hashtag"
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Hashtag/)
  end
end
