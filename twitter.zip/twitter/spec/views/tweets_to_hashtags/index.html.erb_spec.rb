require 'rails_helper'

RSpec.describe "tweets_to_hashtags/index", type: :view do
  before(:each) do
    assign(:tweets_to_hashtags, [
      TweetsToHashtag.create!(
        tweet_id: 2,
        hashtag_id: 3
      ),
      TweetsToHashtag.create!(
        tweet_id: 2,
        hashtag_id: 3
      )
    ])
  end

  it "renders a list of tweets_to_hashtags" do
    render
    assert_select "tr>td", text: 2.to_s, count: 2
    assert_select "tr>td", text: 3.to_s, count: 2
  end
end
