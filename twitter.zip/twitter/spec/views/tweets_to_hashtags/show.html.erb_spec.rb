require 'rails_helper'

RSpec.describe "tweets_to_hashtags/show", type: :view do
  before(:each) do
    @tweets_to_hashtag = assign(:tweets_to_hashtag, TweetsToHashtag.create!(
      tweet_id: 2,
      hashtag_id: 3
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/2/)
    expect(rendered).to match(/3/)
  end
end
