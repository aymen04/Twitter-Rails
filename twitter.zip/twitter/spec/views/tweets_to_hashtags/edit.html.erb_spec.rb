require 'rails_helper'

RSpec.describe "tweets_to_hashtags/edit", type: :view do
  before(:each) do
    @tweets_to_hashtag = assign(:tweets_to_hashtag, TweetsToHashtag.create!(
      tweet_id: 1,
      hashtag_id: 1
    ))
  end

  it "renders the edit tweets_to_hashtag form" do
    render

    assert_select "form[action=?][method=?]", tweets_to_hashtag_path(@tweets_to_hashtag), "post" do

      assert_select "input[name=?]", "tweets_to_hashtag[tweet_id]"

      assert_select "input[name=?]", "tweets_to_hashtag[hashtag_id]"
    end
  end
end
