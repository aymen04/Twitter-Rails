require 'rails_helper'

RSpec.describe "tweets_to_hashtags/new", type: :view do
  before(:each) do
    assign(:tweets_to_hashtag, TweetsToHashtag.new(
      tweet_id: 1,
      hashtag_id: 1
    ))
  end

  it "renders new tweets_to_hashtag form" do
    render

    assert_select "form[action=?][method=?]", tweets_to_hashtags_path, "post" do

      assert_select "input[name=?]", "tweets_to_hashtag[tweet_id]"

      assert_select "input[name=?]", "tweets_to_hashtag[hashtag_id]"
    end
  end
end
