module HashtagsHelper
end
