class TweetsToHashtagsController < ApplicationController
  before_action :set_tweets_to_hashtag, only: %i[ show edit update destroy ]

  # GET /tweets_to_hashtags or /tweets_to_hashtags.json
  def index
    @tweets_to_hashtags = TweetsToHashtag.all
  end

  # GET /tweets_to_hashtags/1 or /tweets_to_hashtags/1.json
  def show
  end

  # GET /tweets_to_hashtags/new
  def new
    @tweets_to_hashtag = TweetsToHashtag.new
  end

  # GET /tweets_to_hashtags/1/edit
  def edit
  end

  # POST /tweets_to_hashtags or /tweets_to_hashtags.json
  def create
    @tweets_to_hashtag = TweetsToHashtag.new(tweets_to_hashtag_params)

    respond_to do |format|
      if @tweets_to_hashtag.save
        format.html { redirect_to tweets_to_hashtag_url(@tweets_to_hashtag), notice: "Tweets to hashtag was successfully created." }
        format.json { render :show, status: :created, location: @tweets_to_hashtag }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @tweets_to_hashtag.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /tweets_to_hashtags/1 or /tweets_to_hashtags/1.json
  def update
    respond_to do |format|
      if @tweets_to_hashtag.update(tweets_to_hashtag_params)
        format.html { redirect_to tweets_to_hashtag_url(@tweets_to_hashtag), notice: "Tweets to hashtag was successfully updated." }
        format.json { render :show, status: :ok, location: @tweets_to_hashtag }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @tweets_to_hashtag.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /tweets_to_hashtags/1 or /tweets_to_hashtags/1.json
  def destroy
    @tweets_to_hashtag.destroy

    respond_to do |format|
      format.html { redirect_to tweets_to_hashtags_url, notice: "Tweets to hashtag was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_tweets_to_hashtag
      @tweets_to_hashtag = TweetsToHashtag.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def tweets_to_hashtag_params
      params.require(:tweets_to_hashtag).permit(:tweet_id, :hashtag_id)
    end
end
