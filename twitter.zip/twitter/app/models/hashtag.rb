class Hashtag < ApplicationRecord
    has_many :tweets_to_hashtags
    has_many :tweets, through: :tweets_to_hashtags
    validates :hashtag, uniqueness: true
end
