class TweetsToHashtag < ApplicationRecord
    belongs_to :user
    belongs_to :tweets_to_hashtags
end
