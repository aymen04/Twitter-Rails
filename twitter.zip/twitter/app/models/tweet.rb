class Tweet < ApplicationRecord
    belongs_to :user
    has_many :tweets_to_hashtags
    has_many :hashtags, through: :tweets_to_hashtags
end
